"""
FitBuddy application package.
"""
